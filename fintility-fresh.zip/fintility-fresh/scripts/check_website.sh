#!/usr/bin/env bash
#
# Task 2: Checks if a website is available and logs the result.
#
# Usage:
#   ./check_website.sh https://example.com
#   ./check_website.sh https://example.com /custom/path/website_check.log
#
# Run on a schedule via cron (every 5 minutes):
#   */5 * * * * /path/to/check_website.sh https://example.com >> /var/log/website_check_cron.log 2>&1

set -euo pipefail

URL="${1:-}"
LOG_FILE="${2:-./website_check.log}"
TIMEOUT_SECONDS=10

if [[ -z "$URL" ]]; then
  echo "Usage: $0 <url> [log_file]"
  exit 1
fi

TIMESTAMP="$(date '+%Y-%m-%d %H:%M:%S')"

# -s  : silent (no progress meter)
# -o  : discard the response body, we only need the status
# -w  : print the HTTP status code
# --max-time : don't hang forever if the site is unreachable
set +e
HTTP_STATUS=$(curl -s -o /dev/null -w "%{http_code}" --max-time "$TIMEOUT_SECONDS" "$URL")
CURL_EXIT=$?
set -e
if [[ "$CURL_EXIT" -ne 0 || -z "$HTTP_STATUS" ]]; then
  HTTP_STATUS="000"
fi

if [[ "$HTTP_STATUS" =~ ^2|^3 ]]; then
  STATUS="UP"
else
  STATUS="DOWN"
fi

LOG_LINE="[$TIMESTAMP] URL=$URL STATUS=$STATUS HTTP_CODE=$HTTP_STATUS"
echo "$LOG_LINE" | tee -a "$LOG_FILE"

# Non-zero exit on failure so it can be chained into alerting
[[ "$STATUS" == "DOWN" ]] && exit 1 || exit 0
