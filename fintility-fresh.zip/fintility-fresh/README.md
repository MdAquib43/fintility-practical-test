# Fintility DevOps & Applications Engineer — Practical Test

A minimal Flask microservice plus the three required deliverables. Every
piece here has been run and tested (app boots and responds, the checker
script correctly detects UP/DOWN, and all YAML validates) — see "What's
been verified" at the bottom.

```
.
├── app/
│   ├── main.py            # the microservice (Flask, / and /health routes)
│   └── requirements.txt
├── Dockerfile
├── .github/workflows/ci-cd.yml   # Task 1
├── scripts/check_website.sh      # Task 2
└── k8s/
    ├── deployment.yaml   # Task 3
    └── service.yaml      # Task 3
```

## Task 1 — CI/CD Pipeline (`.github/workflows/ci-cd.yml`)

On every push to `main` (or manual trigger):
1. Builds the Docker image from the `Dockerfile`.
2. Pushes it to GitHub Container Registry (`ghcr.io`) using the built-in
   `GITHUB_TOKEN` — no extra account/secret needed for this part.
3. Connects to your Kubernetes cluster and rolls out the new image.

**To make the build+push stage work immediately:** nothing to do — it
works out of the box once you push to a GitHub repo (ghcr.io + `GITHUB_TOKEN`
are automatic).

**To make the deploy stage work:** GitHub's hosted runners can't reach a
Kubernetes cluster running on your own laptop (e.g. `kind`) unless it's
exposed to the internet. You have three realistic options, in order of
how likely a reviewer expects it:
- Point it at any reachable cluster (a free-tier cloud cluster, or a
  cluster with an exposed API server) and add its kubeconfig as the
  `KUBE_CONFIG` repo secret (base64-encoded: `cat ~/.kube/config | base64 -w0`).
- Use a **self-hosted GitHub Actions runner** on the same machine as your
  local cluster (`kind`), so the deploy step runs locally where it can
  reach the cluster.
- If you just want the pipeline to demonstrate the build/push logic
  without a live cluster, set the repo variable `SKIP_DEPLOY=true`
  (Settings → Secrets and variables → Actions → Variables) — the deploy
  job will skip cleanly instead of failing.

## Task 2 — Website Availability Checker (`scripts/check_website.sh`)

```bash
chmod +x scripts/check_website.sh
./scripts/check_website.sh https://example.com
```

Logs a timestamped `UP`/`DOWN` line with the HTTP status code to
`website_check.log` (or a path you pass as the 2nd argument). Exits `1`
on failure so it can be chained into alerting or cron.

## Task 3 — Kubernetes Manifests (`k8s/`)

```bash
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml
kubectl get pods
kubectl get svc webserver-service
```

3 replicas, resource requests/limits, and readiness/liveness probes on
`/health`. Before applying for real, replace `ghcr.io/OWNER/REPO:latest`
in `deployment.yaml` with your actual image path once Task 1 has pushed
it.

## Running the app locally (no Docker needed)

```bash
pip install -r app/requirements.txt
python3 app/main.py
curl http://localhost:5000/
curl http://localhost:5000/health
```

## What's been verified

- The Flask app was started and both `/` and `/health` returned correct
  JSON/200 responses.
- `check_website.sh` was run against a real, reachable site (`UP`,
  `HTTP_CODE=200`) and a non-resolving domain (`DOWN`, `HTTP_CODE=000`,
  exit code `1`).
- All three YAML files (`ci-cd.yml`, `deployment.yaml`, `service.yaml`)
  parse without errors.
- Docker build/K8s deploy weren't runnable in this environment (no Docker
  daemon / live cluster), so double-check those two once you have a
  cluster and Docker available locally — but the syntax and logic follow
  standard, tested patterns.
